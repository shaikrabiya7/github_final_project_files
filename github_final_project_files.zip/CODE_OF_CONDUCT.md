# Code of Conduct

## Our Pledge
We pledge to make participation in our project and community a harassment-free experience for everyone.

## Our Standards
- Use welcoming and inclusive language  
- Be respectful of differing viewpoints  
- Accept constructive criticism gracefully  
- Focus on what is best for the community  

## Enforcement
Instances of unacceptable behavior can be reported to the project maintainers.
